/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejerciciosentrega;

import java.io.Serializable;

class Vehiculo implements Serializable {
    private String matricula;
    private String marca;
    private double tamañoDeposito;
    private String modelo;

    //constructor
    public Vehiculo(String matricula, String marca, double tamañoDeposito, String modelo) {
        this.matricula = matricula;
        this.marca = marca;
        this.tamañoDeposito = tamañoDeposito;
        this.modelo = modelo;
    }

    //get y set
    
    public String getMatricula() {
        return matricula;
    }

    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public double getTamañoDeposito() {
        return tamañoDeposito;
    }

    public void setTamañoDeposito(double tamañoDeposito) {
        this.tamañoDeposito = tamañoDeposito;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    @Override
    public String toString() {
        return "Vehiculo{" +
                "matricula='" + matricula + '\'' +
                ", marca='" + marca + '\'' +
                ", tamañoDeposito=" + tamañoDeposito +
                ", modelo='" + modelo + '\'' +
                '}';
    }
    
}