/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejerciciosentrega;
import java.io.*;
import java.nio.*;
import java.util.Scanner;

/**
 *
 * @author sergi
 */
public class ej2 {

     public static void main(String[] args) throws IOException{
         Scanner scanner = new Scanner(System.in);

        //ruta fichero ejemplo: C:\Users\sergi\Desktop\Sergio\clase\apps\entrega\fichero2.txt
        System.out.print("Introduce la ruta del fichero: ");
        String rutaFichero = scanner.nextLine();

        //texto ejemplo: Entrega de Sergio
        System.out.print("Introduce el texto que deseas escribir en el fichero: ");
        String texto = scanner.nextLine();

        
        //creamos un espacio entre lo que pedimos y lo que ejecutamos
        System.out.print("----------------------------------------------------\n");
        
        escribirFichero(rutaFichero,texto);
        invertirMayusculas(rutaFichero);
        mostrarEnMayusculas(rutaFichero);
        scanner.close();
         
         
     }
     
     //Métodos
     
    public static void mostrarEnMayusculas(String rutaFichero) throws FileNotFoundException, IOException {
        
                //Leer fichero 
        FileReader fich = new FileReader(rutaFichero);
        //alamcenamos los carácteres en este array
        char cadenaleer[]=new char[150];
        int i;
        //mientras haya caracteres a leer, fin cuando es -1
        while ((i = fich.read(cadenaleer)) !=-1){
            //convertios el char en string para poder ponerle el uppercase
            System.out.println("Texto en mayúsculas:\n" + String.valueOf(cadenaleer).toUpperCase());
        }
        //cierra fichero
        fich.close();
        
    }
    
    public static void invertirMayusculas(String rutaFichero) throws FileNotFoundException, IOException {
        FileReader fich = new FileReader(rutaFichero);
        char cadenaleer[] = new char[150];
        int j;
        while ((j = fich.read(cadenaleer)) != -1) {
            //hago un for para ir letra por letra y saber si está en  mayúcula o no y en el if identificarlo y cambiarlo
            for (int i = 0; i < j; i++) {
                char letra = cadenaleer[i];

                // invertir mayúsculas a minúsculas y viceversa
                if (Character.isUpperCase(letra)) {
                    cadenaleer[i] = Character.toLowerCase(letra);
                } else if (Character.isLowerCase(letra)) {
                    cadenaleer[i] = Character.toUpperCase(letra);
                }
            }
        }

        System.out.println("Texto con mayúsculas y minúsculas invertidas:\n" + String.valueOf(cadenaleer));
        fich.close();
    }
        

    
    
    public static void escribirFichero(String rutaFichero, String texto) throws IOException{
         //crear el flujo
         FileWriter fic = new FileWriter(rutaFichero);
         //escribimos algo
         //convierte string en array    
         char [] cad= texto.toCharArray();
         //recorremos el array con un for
            for(int i=0; i<cad.length; i++){
            fic.write(cad[i]); //se va escribiendo un caracter
            }
        //cierra fichero
        fic.close();


    }
    
}
