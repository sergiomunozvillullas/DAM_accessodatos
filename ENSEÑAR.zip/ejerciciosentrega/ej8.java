/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejerciciosentrega;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.Scanner;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

/**
 *
 * @author sergi
 */
public class ej8 {
    
    public static void main(String[] args) {
        
        //menú que puedes saltarte el punto 2 si no quieres hacer ninguna modificación 
        //(añadir los datos bien o saldrá con erroes ya que usamos Strings, Ints y floats)
        
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("Menú de opciones:");
            System.out.println("1. Crear un .dat con empleados ya creados");
            System.out.println("2. Modificar los empleados ");
            System.out.println("3. Crear un XML de los empleados ");
            System.out.println("4. Leer el XML de los empleados");
            System.out.println("5. Salir");
            System.out.print("Seleccione una opción: ");

            int opcion = scanner.nextInt();

            switch (opcion) {
                case 1:
                    System.out.println("-------------------------------------");
                    System.out.println("Ha seleccionado la Opción 1.");
                    crearEmple();
                    System.out.println("-------------------------------------");
                    break;
                case 2:
                    System.out.println("-------------------------------------");
                    System.out.println("Ha seleccionado la Opción 2.");
                    modificarEmpleado();
                    System.out.println("-------------------------------------");
                    break;
                case 3:
                    System.out.println("-------------------------------------");
                    System.out.println("Ha seleccionado la Opción 3.");
                    crearXML();
                    System.out.println("-------------------------------------");
                    break;
                case 4:
                    System.out.println("-------------------------------------");
                    System.out.println("Ha seleccionado la Opción 4.");
                    leerXML();
                    System.out.println("-------------------------------------");
                    break;
                case 5:
                    System.out.println("Saliendo del programa.");
                    System.exit(0); // Salir del programa
                default:
                    System.out.println("Opción no válida. Intente de nuevo.");
                    break;
            }
        }

    }

    private static void leerXML(){
               try {
            // Cargar el archivo XML
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document document = builder.parse(new File("empleados.xml"));
            document.getDocumentElement().normalize();

            System.out.println("Elemento raíz: " + document.getDocumentElement().getNodeName());
            NodeList empleados = document.getElementsByTagName("Empleado");

            for (int i = 0; i < empleados.getLength(); i++) {
                Node empleado = empleados.item(i);

                if (empleado.getNodeType() == Node.ELEMENT_NODE) {
                    Element elemento = (Element) empleado;
                    System.out.println("\nCódigo: " + getNodo("Codigo", elemento));
                    System.out.println("Nombre: " + getNodo("Nombre", elemento));
                    System.out.println("Dirección: " + getNodo("Direccion", elemento));
                    System.out.println("Salario: " + getNodo("Salario", elemento));
                    System.out.println("Comisión: " + getNodo("Comision", elemento));
                }
            }
        } catch (ParserConfigurationException | IOException | SAXException e) {
            System.err.println("Error: " + e);
        } 
    }
    
        private static String getNodo(String etiqueta, Element elemento) {
        NodeList nodo = elemento.getElementsByTagName(etiqueta).item(0).getChildNodes();
        if (nodo.getLength() > 0) {
            Node valorNodo = nodo.item(0);
            return valorNodo.getNodeValue();
        }
        return "No hay valor";
    }
    
    private static void crearXML(){
               try {
            RandomAccessFile file = new RandomAccessFile("empleados.dat", "r");

            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document document = builder.newDocument();
            Element rootElement = document.createElement("Empleados");
            document.appendChild(rootElement);

            while (file.getFilePointer() < file.length()) {
                Element empleadoElement = document.createElement("Empleado");

                int codigo = file.readInt();
                empleadoElement.appendChild(createElement(document, "Codigo", String.valueOf(codigo)));

                String nombre = readFixedString(file, 20).trim();
                empleadoElement.appendChild(createElement(document, "Nombre", nombre));

                String direccion = readFixedString(file, 20).trim();
                empleadoElement.appendChild(createElement(document, "Direccion", direccion));

                float salario = file.readFloat();
                empleadoElement.appendChild(createElement(document, "Salario", String.valueOf(salario)));

                float comision = file.readFloat();
                empleadoElement.appendChild(createElement(document, "Comision", String.valueOf(comision)));

                rootElement.appendChild(empleadoElement);
            }

            Source source = new DOMSource(document);
            Result result = new StreamResult(new File("empleados.xml"));
            Transformer transformer = TransformerFactory.newInstance().newTransformer();
            transformer.transform(source, result);

            System.out.println("Archivo XML empleados.xml creado con éxito.");

            file.close();
        } catch (IOException | ParserConfigurationException | TransformerException e) {
            System.err.println("Error: " + e);
        } 
    }
    
        private static Element createElement(Document document, String tagName, String textContent) {
        Element element = document.createElement(tagName);
        element.appendChild(document.createTextNode(textContent));
        return element;
    }
    
    private static void modificarEmpleado(){
                Scanner scanner = new Scanner(System.in);

        System.out.print("Ingrese el código del empleado: ");
        int codigo = scanner.nextInt();
        scanner.nextLine();  // Consumir la nueva línea en el búfer

        System.out.print("Ingrese el nuevo nombre: ");
        String nuevoNombre = scanner.nextLine();

        System.out.print("Ingrese la nueva dirección: ");
        String nuevaDireccion = scanner.nextLine();

        System.out.print("Ingrese el nuevo salario: ");
        float nuevoSalario = scanner.nextFloat();

        System.out.print("Ingrese la nueva comisión: ");
        float nuevaComision = scanner.nextFloat();

        try {
            RandomAccessFile file = new RandomAccessFile("empleados.dat", "rw");

            boolean empleadoEncontrado = false;

            while (file.getFilePointer() < file.length()) {
                int codigoEmpleado = file.readInt();

                if (codigoEmpleado == codigo) {
                    // Modificar los datos del empleado
                    file.writeFloat(nuevoSalario);
                    file.writeFloat(nuevaComision);
                    writeFixedString(file, nuevoNombre, 20);
                    writeFixedString(file, nuevaDireccion, 20);
                    empleadoEncontrado = true;
                    System.out.println("Datos del empleado actualizados.");
                    break;
                } else {
                    // Saltar los datos del empleado no coincidente
                    file.skipBytes(42);
                }
            }

            if (!empleadoEncontrado) {
                System.out.println("Empleado no encontrado.");
            }

            file.close();
        } catch (IOException e) {
            System.err.println("Error: " + e);
        }
    }
    
    private static void crearEmple(){
                try {
            RandomAccessFile file = new RandomAccessFile("empleados.dat", "rw");

            // Datos ficticios de empleados
            int[] codigos = {1, 2, 3, 4, 5};
            String[] nombres = {"Juan", "Pedro", "Luis", "Alberto", "Jose Maria"};
            String[] direcciones = {"Calle Juan", "Calle Pedro", "Calle Luis", "Calle Alberto", "Calle Jose Maria"};
            float[] salarios = {123.0f, 342.0f, 234.0f, 53.0f, 567.0f};
            float[] comisiones = {23.0f, 43.0f, 6.0f, 2.0f, 76.0f};

            for (int i = 0; i < 5; i++) {
                file.writeInt(codigos[i]);
                writeFixedString(file, nombres[i], 20);
                writeFixedString(file, direcciones[i], 20);
                file.writeFloat(salarios[i]);
                file.writeFloat(comisiones[i]);
            }

            file.close();
            System.out.println("Archivo empleados.dat creado con éxito.");
        } catch (IOException e) {
            System.err.println("Error: " + e);
        }
    }
    
    
    //metodo para que me lea la cadena de un archivo binario cogiendo el archivo, la cadena a leer y la longitud que quiero poner
    //elimina caracteres o añade caracteres en blanco para igualar la longitud de la cadena
    //estos metodos los he tenido que buscar para finalizar el codigo sino me salian errores como que me leia el nombre a la mitad
    private static void writeFixedString(RandomAccessFile file, String s, int length) throws IOException {
        if (s.length() > length) {
            s = s.substring(0, length);
        } else if (s.length() < length) {
            int padding = length - s.length();
            s = String.format("%-" + padding + "s%s", "", s);
        }
        file.writeChars(s);
    }
    
        private static String readFixedString(RandomAccessFile file, int length) throws IOException {
        char[] chars = new char[length];
        for (int i = 0; i < length; i++) {
            chars[i] = file.readChar();
        }
        return new String(chars);
    }
    
}