/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejerciciosentrega;
import java.io.*;
import java.nio.*;

/**
 *
 * @author sergi
 */
public class ej1 {

     public static void main(String[] args) throws IOExceptions, FileNotFoundException, IOException{
        //directorio que creo a partir del actual
        File dir = new File("C:\\Users\\sergi\\Desktop\\Sergio\\clase\\apps\\entrega");
        //creo el fichero en la ruta de arriba
        File f1 = new File(dir,"fichero1.txt");
        //creo la carpeta con la ruta de la varibale dir
        dir.mkdir();
        //crear el fichero
        try { 
            if (f1.createNewFile()){
            System.out.println("Fichero creado correctamente");
            }else{
            System.out.println("No se ha podido crear el fichero");
            }
            }
        catch (IOException ioe) {}  
         //escribimos en el fichero
         //crear el flujo
         FileWriter fic = new FileWriter(f1);
         //escribimos algo
         String cadena ="Entrega de Sergio";
         //convierte string en array    
         char [] cad= cadena.toCharArray();
         //recorremos el array con un for
            for(int i=0; i<cad.length; i++){
            fic.write(cad[i]); //se va escribiendo un caracter
            }
        //cierra fichero
        fic.close();
            
        //Separamos apartados para que quede mas limpio
        System.out.println("--------------------------------------------------");
        
        //Leer fichero 
        FileReader fich = new FileReader(f1);
        //alamcenamos los carácteres en este array
        char cadenaleer[]=new char[150];
        int i;
        char espacio = ' ';
        //mientras haya caracteres a leer, fin cuando es -1
        while ((i = fich.read(cadenaleer)) !=-1){
            //eliminamos los espacios
            for (int j = 0; j < i; j++) {
                if (cadenaleer[j] != espacio) {
                System.out.print(cadenaleer[j]);
                }
            }
        }
        //cierra fichero
        fich.close();
         
         
         
         
         
         
     }
}
