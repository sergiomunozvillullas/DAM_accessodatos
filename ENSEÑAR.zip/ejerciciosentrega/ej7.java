package ejerciciosentrega;

import java.io.*;
import java.util.Scanner;

public class ej7 {
    public static void main(String[] args) throws IOException, ClassNotFoundException {
        Scanner scanner = new Scanner(System.in);
        Vehiculo vehiculo; // Defino variable vehiculo

        File fichero = new File("C:\\Users\\sergi\\Desktop\\Sergio\\clase\\apps\\entrega\\vehiculos.dat");

        FileOutputStream fileout = new FileOutputStream(fichero, true);
        ObjectOutputStream dataOS = new ObjectOutputStream(fileout);

        System.out.print("Introduce la matricula: ");
        String matricula = scanner.nextLine();
        System.out.print("Introduce la marca: ");
        String marca = scanner.nextLine();
        System.out.print("Introduce el tamaño del depósito: ");
        double tamañoDeposito = Double.parseDouble(scanner.nextLine());
        System.out.print("Introduce el modelo: ");
        String modelo = scanner.nextLine();

        vehiculo = new Vehiculo(matricula, marca, tamañoDeposito, modelo);
        dataOS.writeObject(vehiculo);

        dataOS.close();
        
        System.out.print("Así queda el fichero: ");


        FileInputStream filein = new FileInputStream(fichero);
        ObjectInputStream dataIS = new ObjectInputStream(filein);
        int i = 1;
        try {
            while (true) {
                vehiculo = (Vehiculo) dataIS.readObject();
                System.out.print("");
                System.out.println(vehiculo.toString());
                i++;
            }
        } catch (EOFException | StreamCorruptedException eo) {
        }
        dataIS.close();
    }
}
