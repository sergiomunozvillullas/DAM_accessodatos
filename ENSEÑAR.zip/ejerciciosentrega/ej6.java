package ejerciciosentrega;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.Scanner;

public class ej6 {


    public static void main(String[] args) throws IOException {
        Scanner scanner = new Scanner(System.in);
//C:\Users\sergi\Desktop\Sergio\clase\apps\entrega\fichero4.txt
//el double se escribe con coma, no con punto.
        System.out.print("Introduce el nombre del fichero: ");
        String filePath = scanner.nextLine();

        while (true) {
            System.out.println("Menú:");
            System.out.println("1. Añadir números double al principio del fichero");
            System.out.println("2. Añadir números double al final del fichero");
            System.out.println("3. Mostrar el fichero");
            System.out.println("4. Sustituir un número");
            System.out.println("5. Salir");
            System.out.print("Elije una opción: ");

            int opcion = scanner.nextInt();
            scanner.nextLine(); 
            
            //Empieza el menú

            switch (opcion) {
                case 1:

                        System.out.print("Introduce el número double a añadir al principio: ");
                        double numeroInicio = scanner.nextDouble();
                        AñadirNumPrincipio(filePath, numeroInicio);

                    break;
                case 2:

                        System.out.print("Introduce el número double a añadir al final: ");
                        double numeroFin = scanner.nextDouble();
                        AñadirNumFinal(filePath, numeroFin);

                    break;
                case 3:

                        mostrarFichero(filePath);

                    break;
                case 4:

                        System.out.print("Introduce el número a sustituir: ");
                        double numeroAntiguo = scanner.nextDouble();
                        System.out.print("Introduce el nuevo número: ");
                        double numeroNuevo = scanner.nextDouble();
                        sustituirNumero(filePath, numeroAntiguo, numeroNuevo);

                    break;
                case 5:
                    scanner.close();
                    return;
                default:
                    System.out.println("Opción no válida.");
            }
        }
    }
    
    
    //Métodos

private static void AñadirNumPrincipio(String filePath, double numero) throws IOException {
    try (RandomAccessFile file = new RandomAccessFile(filePath, "rw")) {
        int numElementos = (int) (file.length() / Double.BYTES);

        // leo todos los numeros del fichero y los guarod en el array
        double[] numerosOriginales = new double[numElementos];
        for (int i = 0; i < numElementos; i++) {
            numerosOriginales[i] = file.readDouble();
        }

        // me posiciono en el inicio y escribo el PRIMER numero
        file.seek(0);

        file.writeDouble(numero);

        // escribo los demas numeros que estaban guardados
        for (int i = 0; i < numerosOriginales.length; i++) {
        file.writeDouble(numerosOriginales[i]);
        }

        System.out.println("Número añadido al principio del fichero.");
    }
}


    private static void AñadirNumFinal(String filePath, double numero) throws IOException {
        try (RandomAccessFile file = new RandomAccessFile(filePath, "rw")) {
            //nos posicionamos al final que es lo que mide el fichero y escribimos el numero
            file.seek(file.length());
            file.writeDouble(numero);
            System.out.println("Número añadido al final del fichero.");
        }
    }

    private static void mostrarFichero(String filePath) throws IOException {
        try (RandomAccessFile file = new RandomAccessFile(filePath, "r")) {
            System.out.println("Contenido del fichero:");
            //while hasta la longitud
            while (file.getFilePointer() < file.length()) {
                System.out.println(file.readDouble());
            }
        }
    }

    private static void sustituirNumero(String filePath, double numeroAntiguo, double numeroNuevo) throws IOException {
        //creamos el tamaño del double en un int para poder utlizarlo con la posiciion que depues vamos a crearla en int y poder utilizarla
        int tamañodouuble = Double.BYTES;
        try (RandomAccessFile file = new RandomAccessFile(filePath, "rw")) {
            int pos = 0; //si es muy corto puedo utilizar un long para que la capacidad sea mayor
            while (pos < file.length()) {
                if (file.readDouble() == numeroAntiguo) {
                    file.seek(pos);
                    file.writeDouble(numeroNuevo);
                    System.out.println("Número sustituido.");
                    return;
                }
                pos += tamañodouuble;
            }

            System.out.println("El número a sustituir no se encontró en el fichero.");
        }
    }
}
