/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejerciciosentrega;
import java.io.*;
import java.nio.*;
import java.util.Scanner;
import java.util.Random;
import java.io.File;
/**
 *
 * @author sergi
 */
public class ej4 {
    public static void main(String[] args) {
        try {
            Scanner scanner = new Scanner(System.in);
            Random random = new Random();

            System.out.print("Introduce un número: ");
            String numero = scanner.nextLine();
            int num = Integer.parseInt(numero);
            
            //C:\Users\sergi\Desktop\Sergio\clase\apps\entrega\fichero3.dat
            System.out.print("Introduce la ruta del fichero: ");
            String rutaFichero = scanner.nextLine();

            //si existe el fichero lee y escribe por 2 sino solo escribe
            File fichero = new File(rutaFichero);

            
            
            // flujo para escribir
            //el true hace que no se sobreescriba
            FileOutputStream fileout = new FileOutputStream(fichero,true);
            DataOutputStream dataOS = new DataOutputStream(fileout);

            // Escribir en el fichero
            for (int i = 0; i < num; i++) {
                int randomInt = random.nextInt(101);
                dataOS.writeInt(randomInt);
            }

            dataOS.close();

            // flujo para leer de nuevo
            FileInputStream filein2 = new FileInputStream(fichero);
            DataInputStream dataIS2 = new DataInputStream(filein2);

            // Leer en el fichero
            try {
                // Leer todos los enteros del fichero, mientras haya numeros (true) sigue
                while (true) {
                    System.out.println(dataIS2.readInt());
                }
            } catch (EOFException e) {
                // Se alcanzó el final del fichero
                dataIS2.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}