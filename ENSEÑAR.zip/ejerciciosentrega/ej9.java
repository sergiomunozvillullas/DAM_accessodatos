/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejerciciosentrega;

import java.io.File;
import java.io.FileOutputStream;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Text;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

public class ej9 {

    public static void main(String[] args) {
        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            Document document = factory.newDocumentBuilder().newDocument();

            Element contactos = document.createElement("contactos");
            document.appendChild(contactos);

            // Crear el primer conjunto de datos de contacto
            Element persona1 = document.createElement("persona");
            persona1.setAttribute("DNI", "434235");

            Element nombre1 = document.createElement("nombre");
            Text nombreTexto1 = document.createTextNode("Pepe");
            nombre1.appendChild(nombreTexto1);

            Element apellido1 = document.createElement("apellido");
            Text apellidoTexto1 = document.createTextNode("Pinillos");
            apellido1.appendChild(apellidoTexto1);

            Element fechanacimiento1 = document.createElement("fechanacimiento");
            Element diaNacimiento1 = document.createElement("dia");
            Text diaTexto1 = document.createTextNode("30");
            diaNacimiento1.appendChild(diaTexto1);
            Element mesNacimiento1 = document.createElement("mes");
            Text mesTexto1 = document.createTextNode("3");
            mesNacimiento1.appendChild(mesTexto1);
            Element anioNacimiento1 = document.createElement("anio");
            Text anioTexto1 = document.createTextNode("1976");
            anioNacimiento1.appendChild(anioTexto1);
            fechanacimiento1.appendChild(diaNacimiento1);
            fechanacimiento1.appendChild(mesNacimiento1);
            fechanacimiento1.appendChild(anioNacimiento1);

            Element direccion1 = document.createElement("direccion");
            Element calle1 = document.createElement("calle");
            Text calleTexto1 = document.createTextNode("Avenida de la Felicidad");
            calle1.appendChild(calleTexto1);
            Element numero1 = document.createElement("numero");
            Text numeroTexto1 = document.createTextNode("34");
            numero1.appendChild(numeroTexto1);
            Element poblacion1 = document.createElement("poblacion");
            Text poblacionTexto1 = document.createTextNode("Villaarriba del Condado");
            poblacion1.appendChild(poblacionTexto1);
            Element pais1 = document.createElement("pais");
            Text paisTexto1 = document.createTextNode("Libertonia");
            pais1.appendChild(paisTexto1);
            direccion1.appendChild(calle1);
            direccion1.appendChild(numero1);
            direccion1.appendChild(poblacion1);
            direccion1.appendChild(pais1);

            persona1.appendChild(nombre1);
            persona1.appendChild(apellido1);
            persona1.appendChild(fechanacimiento1);
            persona1.appendChild(direccion1);

            // Crear el segundo conjunto de datos de contacto (similar al primero)
            Element persona2 = document.createElement("persona");
            persona2.setAttribute("DNI", "63463636");

            Element nombre2 = document.createElement("nombre");
            Text nombreTexto2 = document.createTextNode("Pepito");
            nombre2.appendChild(nombreTexto2);

            Element apellido2 = document.createElement("apellido");
            Text apellidoTexto2 = document.createTextNode("Grillo");
            apellido2.appendChild(apellidoTexto2);

            Element fechanacimiento2 = document.createElement("fechanacimiento");
            Element diaNacimiento2 = document.createElement("dia");
            Text diaTexto2 = document.createTextNode("12");
            diaNacimiento2.appendChild(diaTexto2);
            Element mesNacimiento2 = document.createElement("mes");
            Text mesTexto2 = document.createTextNode("8");
            mesNacimiento2.appendChild(mesTexto2);
            Element anioNacimiento2 = document.createElement("anio");
            Text anioTexto2 = document.createTextNode("1954");
            anioNacimiento2.appendChild(anioTexto2);
            fechanacimiento2.appendChild(diaNacimiento2);
            fechanacimiento2.appendChild(mesNacimiento2);
            fechanacimiento2.appendChild(anioNacimiento2);

            Element direccion2 = document.createElement("direccion");
            Element calle2 = document.createElement("calle");
            Text calleTexto2 = document.createTextNode("Calle de las Flores");
            calle2.appendChild(calleTexto2);
            Element numero2 = document.createElement("numero");
            Text numeroTexto2 = document.createTextNode("25");
            numero2.appendChild(numeroTexto2);
            Element poblacion2 = document.createElement("poblacion");
            Text poblacionTexto2 = document.createTextNode("Villaarriba del Condado");
            poblacion2.appendChild(poblacionTexto2);
            Element pais2 = document.createElement("pais");
            Text paisTexto2 = document.createTextNode("Libertonia");
            pais2.appendChild(paisTexto2);
            direccion2.appendChild(calle2);
            direccion2.appendChild(numero2);
            direccion2.appendChild(poblacion2);
            direccion2.appendChild(pais2);

            persona2.appendChild(nombre2);
            persona2.appendChild(apellido2);
            persona2.appendChild(fechanacimiento2);
            persona2.appendChild(direccion2);

            // Agregar los conjuntos de datos de contacto al elemento "contactos"
            contactos.appendChild(persona1);
            contactos.appendChild(persona2);

            DOMSource source = new DOMSource(document);
            StreamResult result = new StreamResult(new FileOutputStream(new File("contactos.xml")));
            Transformer transformer = TransformerFactory.newInstance().newTransformer();
            transformer.transform(source, result);

            System.out.println("contacto.xml creado.");
        } catch (Exception e) {
            System.err.println("Error: " + e);
        }
    }
}
