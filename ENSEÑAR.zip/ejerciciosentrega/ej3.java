/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejerciciosentrega;
import java.io.*;
import java.nio.*;
import java.util.Scanner;
/**
 *
 * @author sergi
 */
public class ej3 {
    public static void main(String[] args) throws IOException{
     
        Scanner scanner = new Scanner(System.in);

        //ruta fichero ejemplo: C:\Users\sergi\Desktop\Sergio\clase\apps\entrega\fichero1.txt
        System.out.print("Introduce la ruta del fichero: ");
        String rutaFichero = scanner.nextLine();
        
        //ruta fichero ejemplo: C:\Users\sergi\Desktop\Sergio\clase\apps\entrega\fichero2.txt
        System.out.print("Introduce la ruta de otro fichero: ");
        String rutaFichero2 = scanner.nextLine();        
        
        //ruta fichero ejemplo: C:\Users\sergi\Desktop\Sergio\clase\apps\entrega
        System.out.print("Introduce la ruta de destino: ");
        String rutaDestino = scanner.nextLine();    
        copiarEnUno(rutaFichero, rutaFichero2, rutaDestino);
        
        
    }

    
        public static void copiarEnUno(String rutaFichero, String rutaFichero2, String rutaDestino) throws FileNotFoundException, IOException {

        //creo varible de ficheros a partir de las rutas
        File fi1 = new File(rutaFichero);
        File fi2 = new File(rutaFichero2);

        //directorio que creo a partir del actual
        File dir = new File(rutaDestino);
        //creo la carpeta con la ruta de la varibale dir        
        dir.mkdir();
        
        String nombre1 = fi1.getName().substring(0,fi1.getName().lastIndexOf("."));
        String nombre2 = fi2.getName().substring(0,fi2.getName().lastIndexOf("."));
        
        //creo el fichero en la ruta de arriba y con el nombre junto
        File f1 = new File(dir.getAbsolutePath()+"\\"+nombre1+"_"+nombre2+".txt");
        
        if(f1.exists()){
        System.out.println("Este fichero ya existe");
        }else{

        FileWriter ficheronuevo = new FileWriter(f1); //Crear el flujo

        
        //Leer fichero 
        FileReader fich = new FileReader(rutaFichero);

        //Leer fichero 
        FileReader fich2 = new FileReader(rutaFichero2);
        //alamcenamos los carácteres en este array
        char cadenaleer[]=new char[150];
        char cadenaleer2[]=new char[150];
        int i;
        int k;
        
        
        //read 1
        //mientras haya caracteres a leer, fin cuando es -1
        while ((i = fich.read(cadenaleer)) !=-1){

                ficheronuevo.write(String.valueOf(cadenaleer)); //se va escribiendo un caracter
                System.out.println(cadenaleer);  
        }
        
        //dejo una barra en medio de los dos
        ficheronuevo.append('|'); 

        //read 2
        while ((k = fich2.read(cadenaleer2)) !=-1){

                ficheronuevo.append(String.valueOf(cadenaleer2)); //se va escribiendo un caracter
                System.out.println(cadenaleer2);

        }
        ficheronuevo.append('*'); 
        //cierra fichero
        fich.close();
        fich2.close();
        ficheronuevo.close();
        }
    }
    
    
}
