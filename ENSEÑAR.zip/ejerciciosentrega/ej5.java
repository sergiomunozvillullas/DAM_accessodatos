package ejerciciosentrega;
import java.io.*;
import java.util.Scanner;

public class ej5 {
    public static void main(String[] args) {
        try {
            Scanner scanner = new Scanner(System.in);
            String rutaFichero = "C:\\Users\\sergi\\Desktop\\Sergio\\clase\\apps\\entrega\\datos_vehiculo.dat";
            File fichero = new File(rutaFichero);

            // Crear un flujo de salida para escribir en el fichero en modo adición (append)
            FileOutputStream fileOut = new FileOutputStream(fichero, true);
            DataOutputStream dataOut = new DataOutputStream(fileOut);

            System.out.print("Ingrese la matrícula del vehículo: ");
            String matricula = scanner.nextLine();

            System.out.print("Ingrese la marca del vehículo: ");
            String marca = scanner.nextLine();

            System.out.print("Ingrese el tamaño del depósito: ");
            String deposito = scanner.nextLine();
            double dep = Double.parseDouble(deposito);

            System.out.print("Ingrese el modelo del vehículo: ");
            String modelo = scanner.nextLine();

            // Escribir los datos en el fichero
            dataOut.writeUTF(matricula);
            dataOut.writeUTF(marca);
            dataOut.writeDouble(dep);
            dataOut.writeUTF(modelo);

            // Cerrar flujos de salida
            dataOut.close();
            fileOut.close();

            // flujo para leer
            FileInputStream filein = new FileInputStream(fichero);
            DataInputStream dataIS = new DataInputStream(filein);

            // Leer en el fichero
            try {
                // Leer hasta que se alcance el final del fichero
                while (true) {
                    System.out.println("Matrícula: " + dataIS.readUTF());
                    System.out.println("Marca: " + dataIS.readUTF());
                    System.out.println("Depósito: " + dataIS.readDouble());
                    System.out.println("Modelo: " + dataIS.readUTF());
                }
            } catch (EOFException e) {
                // Se alcanzó el final del fichero
                dataIS.close();
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
