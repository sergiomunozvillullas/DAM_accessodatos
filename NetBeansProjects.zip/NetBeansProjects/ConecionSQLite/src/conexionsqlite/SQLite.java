/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package conexionsqlite;

import java.sql.*;
public class SQLite
{	
	public static void main(String[] args) {
	  try
           
	  {
		   //Cargar el driver
		   Class.forName("org.sqlite.JDBC");
		   // Establecemos la conexion con la BD
		   Connection conexion = DriverManager.getConnection    
                   ("jdbc:sqlite:C:/sqlite/prueba.db");   
		   // Preparamos la consulta
		   Statement sentencia = conexion.createStatement();
		   ResultSet resul = sentencia.executeQuery ("SELECT * FROM dept");  
		   
		   // Recorremos el resultado para visualizar cada fila
		   // Se hace un bucle mientras haya registros, se van visualizando
		   while (
resul.next
())
		   {
		     System.out.println (resul.getInt(1) + " " + resul.getString(2)+ " " + 
		    		 resul.getString(3));
		   }
		 
		   resul.close();// Cerrar ResultSet
		   sentencia.close();// Cerrar Statement
  		   conexion.close();//Cerrar conexion
	  } 
   catch (ClassNotFoundException cn) {cn.printStackTrace();} 
   catch (SQLException e) {e.printStackTrace();} 
}//fin de main
}//fin de la clase 