/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package conexionoracle;

import java.sql.*;

public class Oracle 
{
    public static void main(String[] args) 
    {
        try
        {
            //cargar el driver
            Class.forName("oracle.jdbc.OracleDriver");
            
//Class.forName("oracle.jdbc.driver.OracleDriver")
            //Para version de netbeans 8.0 poner
            // Class.forName("oracle.jdbc.driver.OracleDriver");
            //Establecemos la conexion con la BD
            Connection conexion = DriverManager.getConnection
                    ("jdbc:oracle:thin:@localhost:1521:XE","antonio", "antonio");
           
            // Connection conexion = DriverManager.getConnection
            //       ("jdbc😮racle:thin😡localhost:1521:XE","antonio", "antonio");
            //preparamos la consulta
            Statement sentencia = conexion.createStatement();
            ResultSet resul= sentencia.executeQuery ("select dname, count(ename) from emp, dept where emp.deptno=dept.deptno GROUP BY dname");
            //Recorremos el resultado para visualizar cada fila
            //Se hace un bucle mientras haya registros, se van visualizando
            while (
resul.next
())
            {
                System.out.println(resul.getString(1)+" "
                        + " "+resul.getInt(2));
            } 
            resul.close();//cerrar ResultSet
            sentencia.close();//Cerrar Statement
            conexion.close(); //Cerrar Conexion
        
        }
        catch(ClassNotFoundException cn) 
        {
            cn.printStackTrace();
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
    }//main
    
}//clase 