/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package conexionoracle;

import java.sql.*;
public class FuncNombre_DeptOracle {
public static void main(String[] args) {
	  try
	  {				
		 Class.forName ("sun.jdbc.odbc.JdbcOdbcDriver");	
                 Connection conexion = DriverManager.getConnection  
                 ("jdbc😮dbc😮RACLE-XE","antonio", "antonio");  	 
		 //recuperar parametros de main  
		 String dep=args[0];	//departamento
		//construir orden DE LLAMADA
                String sql= "{ ? = call nombre_dep (?, ?) } ";
		 // Preparamos la llamada
		 CallableStatement llamada = conexion.prepareCall(sql);		 	
		 llamada.registerOutParameter(1, Types.VARCHAR); //valor devuelto  				 
		 llamada.setInt(2,Integer.parseInt(dep));       // dep param de entrada
		 llamada.registerOutParameter(3, Types.VARCHAR); //parametro OUT  				 		 
	         llamada.executeUpdate();  //ejecutar el procedimiento
                 System.out.println ("Nombre Dep: "+llamada.getString(1) + 
                 " Localidad: "+llamada.getString(3) );		 		
		 llamada.close();		 
		 conexion.close();   	  	   
	  } catch (Exception e) {e.printStackTrace();} 	
	}//fin de main
}//fin de la clase} 