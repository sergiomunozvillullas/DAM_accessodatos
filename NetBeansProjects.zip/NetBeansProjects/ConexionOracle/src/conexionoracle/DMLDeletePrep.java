/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package conexionoracle;


import java.sql.*;
public class DMLDeletePrep {
 public static void main(String[] args) {
	  try
	  {
		 //Cargar el driver
		 Class.forName("oracle.jdbc.OracleDriver");
		 // Establecemos la conexion con la BD
		 Connection conexion = DriverManager.getConnection 
                 ("jdbc:oracle:thin:@localhost:1521:XE","antonio", "antonio");   
		 //recuperar parametros de main  
		 String deptno=args[0];			
		//construir orden INSERT
		 String sql= "DELETE FROM dept WHERE DEPTNO=?";
		 System.out.println(sql);
		 // Preparamos la sentencia
		 PreparedStatement sentencia = conexion.prepareStatement(sql);
		 
		 sentencia.setInt(1,Integer.parseInt(deptno));

		 
		 int filas = sentencia.executeUpdate();  
		 System.out.println("Filas afectadas: "+filas); 
		 		 
		
  	     // Cerrar Statement
		 sentencia.close();
 	     //Cerrar conexion
		 conexion.close();   
    }		  	   
	 catch (ClassNotFoundException cn) {cn.printStackTrace();} 
     catch (SQLException e) {e.printStackTrace();}		

	}//fin de main   
} 