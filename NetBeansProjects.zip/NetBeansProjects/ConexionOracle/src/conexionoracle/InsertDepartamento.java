/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package conexionoracle;

import java.sql.*;

    
public class InsertDepartamento {

  public static void main(String[] args) {
   try
   {
	  Class.forName("oracle.jdbc.OracleDriver");//Cargar el driver
 	   // Establecemos la conexion con la BD
          Connection conexion = DriverManager.getConnection 
        ("jdbc:oracle:thin:@localhost:1521:XE","antonio", "antonio");   
        //recuperar argumentos de main  
           String deptno=args[0]; // num. departamento
	   String dnombre=args[1]; // nombre
	   String loc=args[2];	   // localidad
		 
       //construir orden INSERT
	   String sql= "INSERT INTO DEPT VALUES "
                   + "(" + deptno + ",'" + dnombre + "','"+loc+ "')";
	   System.out.println(sql);
	   Statement sentencia = conexion.createStatement();
	   int filas = sentencia.executeUpdate(sql);  
	   System.out.println("Filas afectadas: "+filas); 
	 		 	
  	   sentencia.close();  	     // Cerrar Statement
  	   conexion.close();   	     //Cerrar conexiÃ³n		  	   
   } 
   catch (ClassNotFoundException cn) {cn.printStackTrace();} 
   catch (SQLException e) {e.printStackTrace();}		

  }//fin de main
}//fin de la clase 