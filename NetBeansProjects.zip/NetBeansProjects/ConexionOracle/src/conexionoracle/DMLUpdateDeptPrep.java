/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package conexionoracle;

import java.sql.*;
public class DMLUpdateDeptPrep {
 public static void main(String[] args) {
	  try
	  {
		 //Cargar el driver
		 Class.forName("oracle.jdbc.OracleDriver");
		 // Establecemos la conexion con la BD
		 Connection conexion = DriverManager.getConnection 
                 ("jdbc:oracle:thin:@localhost:1521:XE","antonio", "antonio");   
		 //recuperar parametros de main  
		 String dep=args[0];	
		 String subida=args[1];			
		//construir orden UPDATE
		 String sql= "UPDATE emp SET sal= sal + ? WHERE deptno = ?";
		 System.out.println(sql);
		 // Preparamos la sentencia
		 PreparedStatement sentencia = conexion.prepareStatement(sql);
		 
		 sentencia.setInt(2,Integer.parseInt(dep));
		 sentencia.setFloat(1,Float.parseFloat(subida)); 
	    //float num = Float.parseFloat(cadenaEntrada);
		//Double num = Double.parseDouble(cadenaEntrada);
		 int filas = sentencia.executeUpdate ();  
		 System.out.println("Filas afectadas: "+filas); 
  	     // Cerrar Statement
		 sentencia.close();
 	     //Cerrar conexion
		 conexion.close();     	   
	  } catch (Exception e) {e.printStackTrace();} 	
	}//fin de main   
}//fin de la clase 