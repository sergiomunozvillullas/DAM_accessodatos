package Acessodatos2XML;
import java.io.*;
import javax.xml.parsers.*;
import javax.xml.transform.*;
import javax.xml.transform.dom.*;
import javax.xml.transform.stream.*;
import org.w3c.dom.*;

public class ejemplo2 {
  public static void main(String argv[]) throws IOException{
   File fichero = new File("C:\\prueba\\libro.dat");   
   RandomAccessFile file = new RandomAccessFile(fichero, "rw");
   
   int  posicion=0; //para situarnos al principio del fichero        
   Double precio;
   char nombre[] = new char[10], aux;
     
   DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
  
   try{
     DocumentBuilder builder = factory.newDocumentBuilder();
     DOMImplementation implementation = builder.getDOMImplementation();
     Document document = (Document) implementation.createDocument(null, "Libros", null);
     document.setXmlVersion("1.0"); // asignamos la version de nuestro XML
   
     for(;;) {
	 
file.seek(posicion);
 	  
       for (int i = 0; i < nombre.length; i++) {
         aux = file.readChar();//recorro uno a uno los caracteres del apellido 
         nombre[i] = aux;    //los voy guardando en el array
       }   
       String apellidoS= new String(nombre);//convierto a String el array
  	 precio=file.readDouble();  //obtengo salario	  
	   
	   Element raiz = document.createElement("libro"); //nodo empleado
         document.getDocumentElement().appendChild(raiz);                        
         CrearElemento("nombre",apellidoS.trim(), raiz, document); //nombre 
         CrearElemento("precio",Double.toString(precio), raiz, document); //SAL 
	   	
	   posicion= posicion + 36; // me posiciono para el sig empleado	  	  
	   if (file.getFilePointer() == file.length())   break; 

     }//del for que recorre el fichero
		
     Source source = new DOMSource(document);
     Result result = new StreamResult(new java.io.File("libro.xml"));        
     Transformer transformer = TransformerFactory.newInstance().newTransformer();
     transformer.transform(source, result);
	 Result console= new StreamResult(System.out);
     transformer.transform(source, console);
	 
    
    }catch(ParserConfigurationException | DOMException | IOException | TransformerException e){System.err.println("Error: "+e);}
	file.close();  //cerrar fichero 	
 }//de main
 
 //Inserción de los datos del empleado
public static void CrearElemento(String datoEmple, String valor, Element raiz, Document document) {
    Element elem = document.createElement(datoEmple);
    Text text = document.createTextNode(valor);
    raiz.appendChild(elem);
    elem.appendChild(text);
}
} 