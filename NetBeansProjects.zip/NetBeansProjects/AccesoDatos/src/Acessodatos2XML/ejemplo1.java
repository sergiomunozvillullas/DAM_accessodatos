/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Acessodatos2XML;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;

public class ejemplo1 {
 public static void main(String[] args) throws IOException {      
   File fichero = new File("C:\\prueba\\libro.dat");
   //declara el fichero de acceso aleatorio
   RandomAccessFile file = new RandomAccessFile(fichero, "rw");
   //arrays con los datos
   String nombre[] = {"Harry Potter","Petter Pan"};//apellidos 
   Double precio[]={20.0,30.0};//salarios
   
   StringBuffer buffer = null;//buffer para almacenar nombre
   int n=nombre.length;//numero de elementos del array
   
   for (int i=0;i<n; i++){ //recorro los arrays          	  
	 file.writeInt(i+1); //uso i+1 para identificar empleado
     buffer = new StringBuffer( nombre[i] );      
     buffer.setLength(10); //10 caracteres para el nombre
     file.writeChars(buffer.toString());//insertar nombre
	 file.writeDouble(precio[i]);//insertar precio
   }     
   file.close();  //cerrar fichero 
   }
   
} 
