package dom.sax;
public class EjemploExcepcion {
 public static void main(String[] args) {   
    int nume=10, denom=0, cociente;
	cociente=nume/denom;	
    System.out.println("Resultado:" +cociente); 	
 }//   
}
